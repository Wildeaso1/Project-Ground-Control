<h1 align='center'> :flying_saucer: Project-Ground-Control :flying_saucer:</h1>


--Algemene info--

unity version: 2020.3.7f1



<h1><i>Developers</i></h1>

*Martijn van de Meer*

*Leon Boussen*

*Mikey Clarke*

*William Soijer*


<h1><i>Artists</i></h1>

*Max Le Febre*

*Suzan Maas*

*Nils van 't Schip*


# project ......
